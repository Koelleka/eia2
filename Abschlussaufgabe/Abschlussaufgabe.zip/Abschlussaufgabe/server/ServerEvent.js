"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServerEvent = (function () {
    function ServerEvent() {
    }
    return ServerEvent;
}());
exports.ServerEvent = ServerEvent;
//# sourceMappingURL=ServerEvent.js.map
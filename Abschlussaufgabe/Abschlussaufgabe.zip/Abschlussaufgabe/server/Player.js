"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Player = (function () {
    function Player() {
        this.cards = [];
    }
    return Player;
}());
exports.Player = Player;
//# sourceMappingURL=Player.js.map
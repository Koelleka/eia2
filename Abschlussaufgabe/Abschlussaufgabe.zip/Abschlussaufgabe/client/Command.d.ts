declare namespace UnoClient {
    class Command {
        name: string;
        command: string;
        gameId: number;
        lobbyId: number;
        playerId: number;
        cardId: number;
    }
}

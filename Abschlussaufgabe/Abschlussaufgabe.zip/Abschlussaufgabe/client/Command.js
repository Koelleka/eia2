var UnoClient;
(function (UnoClient) {
    var Command = (function () {
        function Command() {
        }
        return Command;
    }());
    UnoClient.Command = Command;
})(UnoClient || (UnoClient = {}));
//# sourceMappingURL=Command.js.map
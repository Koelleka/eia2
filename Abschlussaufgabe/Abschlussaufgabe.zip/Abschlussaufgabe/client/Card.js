var UnoClient;
(function (UnoClient) {
    var Card = (function () {
        function Card() {
        }
        return Card;
    }());
    UnoClient.Card = Card;
})(UnoClient || (UnoClient = {}));
//# sourceMappingURL=Card.js.map
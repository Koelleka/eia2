namespace UnoClient {
    export class Command {
        public name: string;
        public command: string;
        public gameId: number;
        public lobbyId: number;
        public playerId: number;
        public cardId: number;
    }
}
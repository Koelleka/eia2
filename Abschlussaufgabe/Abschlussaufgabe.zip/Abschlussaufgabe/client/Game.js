var UnoClient;
(function (UnoClient) {
    var Game = (function () {
        function Game() {
        }
        return Game;
    }());
    UnoClient.Game = Game;
})(UnoClient || (UnoClient = {}));
//# sourceMappingURL=Game.js.map
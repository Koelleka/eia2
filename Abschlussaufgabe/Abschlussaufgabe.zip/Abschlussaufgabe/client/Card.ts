namespace UnoClient {
    export class Card {
        public id: number;
        public color: string;
        public type: string;
        public isJoker: boolean;
    }
}
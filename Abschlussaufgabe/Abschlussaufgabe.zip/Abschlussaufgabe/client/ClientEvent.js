var UnoClient;
(function (UnoClient) {
    var ClientEvent = (function () {
        function ClientEvent() {
        }
        return ClientEvent;
    }());
    UnoClient.ClientEvent = ClientEvent;
})(UnoClient || (UnoClient = {}));
//# sourceMappingURL=ClientEvent.js.map
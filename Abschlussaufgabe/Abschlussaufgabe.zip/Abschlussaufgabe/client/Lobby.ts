namespace UnoClient {
    export class Lobby {
        public id: number;
        public name: string;
        public static currentLobby: Lobby;
    }
}
declare namespace UnoClient {
    class Card {
        id: number;
        color: string;
        type: string;
        isJoker: boolean;
    }
}

declare namespace UnoClient {
}

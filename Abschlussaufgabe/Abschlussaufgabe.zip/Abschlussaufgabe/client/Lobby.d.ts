declare namespace UnoClient {
    class Lobby {
        id: number;
        name: string;
        static currentLobby: Lobby;
    }
}

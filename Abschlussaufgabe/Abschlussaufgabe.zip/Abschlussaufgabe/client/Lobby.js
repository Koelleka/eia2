var UnoClient;
(function (UnoClient) {
    var Lobby = (function () {
        function Lobby() {
        }
        return Lobby;
    }());
    UnoClient.Lobby = Lobby;
})(UnoClient || (UnoClient = {}));
//# sourceMappingURL=Lobby.js.map